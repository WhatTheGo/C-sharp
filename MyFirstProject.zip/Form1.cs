namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String text = textBox1.Text;
            int[] tab1 = text.Split(' ').Select(n => Convert.ToInt32(n)).ToArray();
            tab1 = insertSort(tab1);
            String tab1Str = listToString(tab1);
            displayList.Text = tab1Str;
        }

        int[] insertSort(int[] tab)
        {
            for (int i = 1; i < tab.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    int temp = tab[j - 1];
                    if (tab[j] < tab[j - 1])
                    {
                        tab[j - 1] = tab[j];
                        tab[j] = temp;
                    }
                }
            }

            return tab;
        }

        string listToString(int[] tab)
        {
            string napis = "";
            for (int i = 0; i < tab.Length; i++)
            {
                napis += $"{tab[i]} ";
            }
            return napis;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void addOne_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(arrayLength.Text, out int n))
            {
                n++;
                arrayLength.Text = Convert.ToString(n);
            }
            else
            {
                arrayLength.Text = "1";
            }

        }

        private void minusOne_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(arrayLength.Text, out int n))
            {
                if(n > 1)
                {
                    n--;
                    arrayLength.Text = Convert.ToString(n);
                }
            }
            else
            {
                arrayLength.Text = "1";
            }
        }
    }
}
