﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            posortowane = new TextBox();
            niePosortowane = new TextBox();
            BubbleSortButton = new Button();
            InsertSortButton = new Button();
            QuickSortButton = new Button();
            status = new Label();
            CountingSortButton = new Button();
            MergeSortButton = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(544, 85);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 32);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(555, 132);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // posortowane
            // 
            posortowane.Location = new Point(120, 292);
            posortowane.Name = "posortowane";
            posortowane.Size = new Size(524, 23);
            posortowane.TabIndex = 2;
            // 
            // niePosortowane
            // 
            niePosortowane.Location = new Point(120, 85);
            niePosortowane.Name = "niePosortowane";
            niePosortowane.Size = new Size(296, 23);
            niePosortowane.TabIndex = 3;
            // 
            // BubbleSortButton
            // 
            BubbleSortButton.Location = new Point(120, 342);
            BubbleSortButton.Name = "BubbleSortButton";
            BubbleSortButton.Size = new Size(75, 61);
            BubbleSortButton.TabIndex = 4;
            BubbleSortButton.Text = "BubbleSort";
            BubbleSortButton.UseVisualStyleBackColor = true;
            BubbleSortButton.Click += BubbleSortButton_Click;
            // 
            // InsertSortButton
            // 
            InsertSortButton.Location = new Point(213, 342);
            InsertSortButton.Name = "InsertSortButton";
            InsertSortButton.Size = new Size(75, 61);
            InsertSortButton.TabIndex = 5;
            InsertSortButton.Text = "InsertSort";
            InsertSortButton.UseVisualStyleBackColor = true;
            InsertSortButton.Click += InsertSortButton_Click;
            // 
            // QuickSortButton
            // 
            QuickSortButton.Location = new Point(306, 342);
            QuickSortButton.Name = "QuickSortButton";
            QuickSortButton.Size = new Size(75, 61);
            QuickSortButton.TabIndex = 6;
            QuickSortButton.Text = "QuickSort";
            QuickSortButton.UseVisualStyleBackColor = true;
            QuickSortButton.Click += QuickSortButton_Click;
            // 
            // status
            // 
            status.AutoSize = true;
            status.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            status.Location = new Point(659, 295);
            status.Name = "status";
            status.Size = new Size(0, 21);
            status.TabIndex = 7;
            // 
            // CountingSortButton
            // 
            CountingSortButton.Location = new Point(396, 342);
            CountingSortButton.Name = "CountingSortButton";
            CountingSortButton.Size = new Size(65, 61);
            CountingSortButton.TabIndex = 8;
            CountingSortButton.Text = "CountingSort";
            CountingSortButton.UseVisualStyleBackColor = true;
            CountingSortButton.Click += CountingSortButton_Click;
            // 
            // MergeSortButton
            // 
            MergeSortButton.Location = new Point(480, 342);
            MergeSortButton.Name = "MergeSortButton";
            MergeSortButton.Size = new Size(65, 61);
            MergeSortButton.TabIndex = 9;
            MergeSortButton.Text = "Merge Sort";
            MergeSortButton.UseVisualStyleBackColor = true;
            MergeSortButton.Click += MergeSortButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(MergeSortButton);
            Controls.Add(CountingSortButton);
            Controls.Add(status);
            Controls.Add(QuickSortButton);
            Controls.Add(InsertSortButton);
            Controls.Add(BubbleSortButton);
            Controls.Add(niePosortowane);
            Controls.Add(posortowane);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private TextBox posortowane;
        private TextBox niePosortowane;
        private Button BubbleSortButton;
        private Button InsertSortButton;
        private Button QuickSortButton;
        private Label status;
        private Button CountingSortButton;
        private Button MergeSortButton;
    }
}
