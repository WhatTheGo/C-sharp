﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            AddFirst = new Button();
            label1 = new Label();
            NumToAdd = new TextBox();
            AddLast = new Button();
            RemoveFirst = new Button();
            RemoveLast = new Button();
            ListLength = new Label();
            SuspendLayout();
            // 
            // AddFirst
            // 
            AddFirst.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            AddFirst.Location = new Point(171, 183);
            AddFirst.Name = "AddFirst";
            AddFirst.Size = new Size(60, 61);
            AddFirst.TabIndex = 0;
            AddFirst.Text = "AddFirst";
            AddFirst.UseVisualStyleBackColor = true;
            AddFirst.Click += AddFirst_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(171, 331);
            label1.Name = "label1";
            label1.Size = new Size(60, 28);
            label1.TabIndex = 2;
            label1.Text = "Lista: ";
            // 
            // NumToAdd
            // 
            NumToAdd.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            NumToAdd.Location = new Point(171, 146);
            NumToAdd.Name = "NumToAdd";
            NumToAdd.Size = new Size(126, 31);
            NumToAdd.TabIndex = 3;
            // 
            // AddLast
            // 
            AddLast.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            AddLast.Location = new Point(237, 183);
            AddLast.Name = "AddLast";
            AddLast.Size = new Size(60, 61);
            AddLast.TabIndex = 4;
            AddLast.Text = "Add Last";
            AddLast.UseVisualStyleBackColor = true;
            AddLast.Click += AddLast_Click;
            // 
            // RemoveFirst
            // 
            RemoveFirst.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            RemoveFirst.Location = new Point(451, 183);
            RemoveFirst.Name = "RemoveFirst";
            RemoveFirst.Size = new Size(88, 61);
            RemoveFirst.TabIndex = 5;
            RemoveFirst.Text = "Remove First";
            RemoveFirst.UseVisualStyleBackColor = true;
            RemoveFirst.Click += RemoveFirst_Click;
            // 
            // RemoveLast
            // 
            RemoveLast.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            RemoveLast.Location = new Point(545, 183);
            RemoveLast.Name = "RemoveLast";
            RemoveLast.Size = new Size(88, 61);
            RemoveLast.TabIndex = 6;
            RemoveLast.Text = "Remove Last";
            RemoveLast.UseVisualStyleBackColor = true;
            RemoveLast.Click += RemoveLast_Click;
            // 
            // ListLength
            // 
            ListLength.AutoSize = true;
            ListLength.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            ListLength.Location = new Point(171, 370);
            ListLength.Name = "ListLength";
            ListLength.Size = new Size(81, 28);
            ListLength.TabIndex = 7;
            ListLength.Text = "Length: ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(ListLength);
            Controls.Add(RemoveLast);
            Controls.Add(RemoveFirst);
            Controls.Add(AddLast);
            Controls.Add(NumToAdd);
            Controls.Add(label1);
            Controls.Add(AddFirst);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button AddFirst;
        private Label label1;
        private TextBox NumToAdd;
        private Button AddLast;
        private Button RemoveFirst;
        private Button RemoveLast;
        private Label ListLength;
    }
}
