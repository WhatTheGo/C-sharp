using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        List list = new List();

        public Form1()
        {
            InitializeComponent();
        }

        string ArrayToString(int[] tab)
        {
            string napis = "";
            for (int i = 0; i < tab.Length; i++)
            {
                napis += $"{tab[i]} ";
            }
            return napis;
        }

        private void AddFirst_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(NumToAdd.Text, out int n))
            {
                list.AddFirst(Int32.Parse(NumToAdd.Text));
                UpdateUi();
            }
            else { MessageBox.Show("Z�a warto��"); }
        }

        private void AddLast_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(NumToAdd.Text, out int n))
            {
                list.AddLast(Int32.Parse(NumToAdd.Text));
                UpdateUi();
            }
            else { MessageBox.Show("Z�a warto��"); }
        }

        private void RemoveFirst_Click(object sender, EventArgs e)
        {
            list.RemoveFirst();
            UpdateUi();
        }

        private void RemoveLast_Click(object sender, EventArgs e)
        {
            list.RemoveLast();
            UpdateUi();
        }

        private void UpdateUi()
        {
            String str = list.DoString();
            label1.Text = "Lista: " + str;
            String len = list.Count.ToString();
            ListLength.Text = "Length: " + len.ToString();
        }
    }
}
