using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            List list = new List();
            list.AddLast(1);
            list.AddLast(2);
            list.AddLast(3);
            list.AddLast(4);
            list.AddLast(5);
            int[] array = list.ToArray();
            array[0] = 20;
            MessageBox.Show(ArrayToString(array));

            InitializeComponent();
        }

        string ArrayToString(int[] tab)
        {
            string napis = "";
            for (int i = 0; i < tab.Length; i++)
            {
                napis += $"{tab[i]} ";
            }
            return napis;
        }
    }
}
