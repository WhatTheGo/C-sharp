﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class List
    {
        public Node First { get; private set; }

        public Node Last { get; private set; }

        public int Count { get; private set; }

        public void AddFirst(int num)
        {
            Node newNode = new Node(num);
            if (this.First == null)
            {
                this.First = newNode;
                this.Last = newNode;
            }
            else
            {
                this.First.Prev = newNode;
                newNode.Next = this.First;
                this.First = newNode;
            }
            Count++;
        }

        public void AddLast(int num)
        {
            Node newNode = new Node(num);
            if (this.First == null)
            {
                this.First = newNode;
                this.Last = newNode;
            }
            else
            {
                newNode.Prev = this.Last;
                this.Last.Next = newNode;
                this.Last = newNode;         
            }
            Count++;
        }

        public String DoString()
        {
            String strList = "";
            Node node = this.First;
            while (node != null)
            {
                int num = node.Data;
                strList += $"{num.ToString()} ";
                node = node.Next;
            }

            return strList;
        }

        public void RemoveFirst()
        {
            if (First == null || this.Count == 0) {  return; }

            First = First.Next;
            First.Prev = null;
            this.Count--;
        }

        public void RemoveLast()
        {
            if (First == null || this.Count == 0) { return; }

            Last = Last.Prev;
            Last.Next = null;
            this.Count--;
        }

        public int[] ToArray()
        {
            int[] array = new int[this.Count];

            Node node = this.First;
            int i = 0;
            while (node != null)
            {
                int num = node.Data;
                array[i++] = num;
                node = node.Next;
            }

            return array;
        }
    }
}
