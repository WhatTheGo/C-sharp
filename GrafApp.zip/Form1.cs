namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        NodeG A = new NodeG(1);
        NodeG B = new NodeG(2);
        NodeG C = new NodeG(3);
        NodeG D = new NodeG(4);
        NodeG E = new NodeG(5);
        NodeG F = new NodeG(6);
        NodeG G = new NodeG(7);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            A.sadziedzi.Add(B);
            A.sadziedzi.Add(C);
            B.sadziedzi.Add(A);
            B.sadziedzi.Add(D);
            B.sadziedzi.Add(E);
            C.sadziedzi.Add(A);
            C.sadziedzi.Add(D);
            C.sadziedzi.Add(F);
            D.sadziedzi.Add(B);
            D.sadziedzi.Add(C);
            D.sadziedzi.Add(F);
            E.sadziedzi.Add(B);
            E.sadziedzi.Add(F);
            F.sadziedzi.Add(E);
            F.sadziedzi.Add(C);
            F.sadziedzi.Add(D);
            F.sadziedzi.Add(G);
            G.sadziedzi.Add(F);

            Graf g = new Graf();
            g.nodes.Add(A);
            g.nodes.Add(B);
            g.nodes.Add(C);
            g.nodes.Add(D);
            g.nodes.Add(E);
            g.nodes.Add(F);
            g.nodes.Add(G);

            MessageBox.Show(g.Wyswietl());
        }
    }
}