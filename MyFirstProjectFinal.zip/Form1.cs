using System.Diagnostics;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        int[] tab;
        Stopwatch stopWatch = new Stopwatch();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String text = textBox1.Text;
            text = text.Trim();
            tab = text.Split(' ').Select(n => Convert.ToInt32(n)).ToArray();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] tab1 = new int[2];
            if (Int32.TryParse(arrayLength.Text, out int n))
            {
                tab1 = new int[n];
            }

            for (int i = 0; i < tab1.Length; i++)
            {
                Random rnd = new Random();
                int num = rnd.Next(100);
                tab1[i] = num;
            }

            String tab1Str = listToString(tab1);
            textBox1.Text = tab1Str;
        }

        private void addOne_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(arrayLength.Text, out int n))
            {
                n++;
                arrayLength.Text = Convert.ToString(n);
            }
            else
                arrayLength.Text = "1";
        }

        private void minusOne_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(arrayLength.Text, out int n))
            {
                if (n > 1)
                {
                    n--;
                    arrayLength.Text = Convert.ToString(n);
                }
            }
            else
                arrayLength.Text = "1";
        }

        int[] insertSort(int[] tab)
        {
            for (int i = 1; i < tab.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    int temp = tab[j - 1];
                    if (tab[j] < tab[j - 1])
                    {
                        tab[j - 1] = tab[j];
                        tab[j] = temp;
                    }
                }
            }

            return tab;
        }

        int[] bubbleSort(int[] tab)
        {
            int n = tab.Length;
            for (int i = 0; i < n - 1; i++)
                for (int j = 0; j < n - i - 1; j++)
                    if (tab[j] > tab[j + 1])
                    {
                        int temp = tab[j];
                        tab[j] = tab[j + 1];
                        tab[j + 1] = temp;
                    }
            return tab;
        }

        int[] mergeSort(int[] tab)
        {
            int[] left;
            int[] right;
            int[] result = new int[tab.Length];

            if (tab.Length <= 1)
                return tab;

            int midPoint = tab.Length / 2;
            left = new int[midPoint];

            if (tab.Length % 2 == 0)
                right = new int[midPoint];
            else
                right = new int[midPoint + 1];

            for (int i = 0; i < midPoint; i++)
                left[i] = tab[i];

            int x = 0;
            for (int i = midPoint; i < tab.Length; i++)
            {
                right[x] = tab[i];
                x++;
            }

            left = mergeSort(left);
            right = mergeSort(right);
            result = merge(left, right);
            return result;
        }


        int[] merge(int[] left, int[] right)
        {
            int resultLength = right.Length + left.Length;
            int[] result = new int[resultLength];
            int indexLeft = 0, indexRight = 0, indexResult = 0;

            while (indexLeft < left.Length || indexRight < right.Length)
            {
                if (indexLeft < left.Length && indexRight < right.Length)
                {
                    if (left[indexLeft] <= right[indexRight])
                    {
                        result[indexResult] = left[indexLeft];
                        indexLeft++;
                        indexResult++;
                    }
                    else
                    {
                        result[indexResult] = right[indexRight];
                        indexRight++;
                        indexResult++;
                    }
                }
                else if (indexLeft < left.Length)
                {
                    result[indexResult] = left[indexLeft];
                    indexLeft++;
                    indexResult++;
                }
                else if (indexRight < right.Length)
                {
                    result[indexResult] = right[indexRight];
                    indexRight++;
                    indexResult++;
                }
            }
            return result;
        }

        int[] QuickSort(int[] tab, int leftIndex, int rightIndex)
        {
            var i = leftIndex;
            var j = rightIndex;
            var pivot = tab[leftIndex];

            while (i <= j)
            {
                while (tab[i] < pivot)
                {
                    i++;
                }

                while (tab[j] > pivot)
                {
                    j--;
                }

                if (i <= j)
                {
                    int temp = tab[i];
                    tab[i] = tab[j];
                    tab[j] = temp;
                    i++;
                    j--;
                }
            }

            if (leftIndex < j)
                QuickSort(tab, leftIndex, j);

            if (i < rightIndex)
                QuickSort(tab, i, rightIndex);

            return tab;
        }

        int[] CountingSort(int[] tab)
        {
            var size = tab.Length;
            var maxElement = tab.Max();
            var occurrences = new int[maxElement + 1];

            for (int i = 0; i < maxElement + 1; i++)
            {
                occurrences[i] = 0;
            }

            for (int i = 0; i < size; i++)
            {
                occurrences[tab[i]]++;
            }

            for (int i = 0, j = 0; i <= maxElement; i++)
            {
                while (occurrences[i] > 0)
                {
                    tab[j] = i;
                    j++;
                    occurrences[i]--;
                }
            }

            return tab;
        }


        string listToString(int[] tab)
        {
            string napis = "";
            for (int i = 0; i < tab.Length; i++)
            {
                napis += $"{tab[i]} ";
            }
            return napis;
        }

        string listToString15(int[] tab)
        {
            string napis = "";
            int n;
            if (tab.Length > 15)
            {
                n = 15;
            }
            else { n = tab.Length; }

            for (int i = 0; i < n; i++)
            {
                napis += $"{tab[i]} ";
            }
            return napis;
        }

        private void InsertSortButton_Click(object sender, EventArgs e)
        {
            stopWatch.Start();
            tab = insertSort(tab);
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            stopWatch.Reset();

            String tab1Str = listToString15(tab);
            displayList.Text = tab1Str;
            sortName.Text = "InsertSort " + elapsedTime;
        }

        private void BubbleSortButton_Click(object sender, EventArgs e)
        {
            stopWatch.Start();
            tab = bubbleSort(tab);
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            stopWatch.Reset();

            String tab1Str = listToString15(tab);
            displayList.Text = tab1Str;
            sortName.Text = "BubbleSort " + elapsedTime;
        }

        private void MergeSortButton_Click(object sender, EventArgs e)
        {
            stopWatch.Start();
            tab = mergeSort(tab);
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            stopWatch.Reset();

            String tab1Str = listToString15(tab);
            displayList.Text = tab1Str;
            sortName.Text = "MergeSort " + elapsedTime;
        }

        private void QuickSortButton_Click(object sender, EventArgs e)
        {
            stopWatch.Start();
            tab = QuickSort(tab, 0, tab.Length - 1);
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            stopWatch.Reset();

            String tab1Str = listToString15(tab);
            displayList.Text = tab1Str;
            sortName.Text = "QuickSort " + elapsedTime;
        }

        private void CountingSortButton_Click(object sender, EventArgs e)
        {
            stopWatch.Start();
            tab = CountingSort(tab);
            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);
            stopWatch.Reset();

            String tab1Str = listToString15(tab);
            displayList.Text = tab1Str;
            sortName.Text = "CountingSort " + elapsedTime;
        }
    }
}
