﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            textBox1 = new TextBox();
            displayList = new TextBox();
            arrayLength = new TextBox();
            splitter1 = new Splitter();
            addOne = new Button();
            minusOne = new Button();
            button2 = new Button();
            InsertSortButton = new Button();
            sortName = new Label();
            BubbleSortButton = new Button();
            MergeSortButton = new Button();
            QuickSortButton = new Button();
            CountingSortButton = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13F);
            button1.Location = new Point(115, 130);
            button1.Name = "button1";
            button1.Size = new Size(120, 36);
            button1.TabIndex = 0;
            button1.Text = "konwertuj";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 15F);
            textBox1.Location = new Point(87, 59);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(180, 34);
            textBox1.TabIndex = 1;
            // 
            // displayList
            // 
            displayList.Font = new Font("Segoe UI", 15F);
            displayList.Location = new Point(87, 285);
            displayList.Name = "displayList";
            displayList.Size = new Size(546, 34);
            displayList.TabIndex = 2;
            // 
            // arrayLength
            // 
            arrayLength.Font = new Font("Segoe UI", 15F);
            arrayLength.Location = new Point(453, 59);
            arrayLength.Name = "arrayLength";
            arrayLength.Size = new Size(52, 34);
            arrayLength.TabIndex = 3;
            // 
            // splitter1
            // 
            splitter1.Location = new Point(0, 0);
            splitter1.Name = "splitter1";
            splitter1.Size = new Size(3, 420);
            splitter1.TabIndex = 4;
            splitter1.TabStop = false;
            // 
            // addOne
            // 
            addOne.Anchor = AnchorStyles.Bottom;
            addOne.Location = new Point(505, 50);
            addOne.Name = "addOne";
            addOne.Size = new Size(35, 23);
            addOne.TabIndex = 5;
            addOne.Text = "+";
            addOne.UseVisualStyleBackColor = true;
            addOne.Click += addOne_Click;
            // 
            // minusOne
            // 
            minusOne.Location = new Point(505, 79);
            minusOne.Name = "minusOne";
            minusOne.Size = new Size(35, 23);
            minusOne.TabIndex = 6;
            minusOne.Text = "-";
            minusOne.UseVisualStyleBackColor = true;
            minusOne.Click += minusOne_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 13F);
            button2.Location = new Point(438, 130);
            button2.Name = "button2";
            button2.Size = new Size(120, 36);
            button2.TabIndex = 7;
            button2.Text = "generuj";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // InsertSortButton
            // 
            InsertSortButton.Font = new Font("Segoe UI", 13F);
            InsertSortButton.Location = new Point(87, 350);
            InsertSortButton.Name = "InsertSortButton";
            InsertSortButton.Size = new Size(66, 58);
            InsertSortButton.TabIndex = 8;
            InsertSortButton.Text = "Insert Sort";
            InsertSortButton.UseVisualStyleBackColor = true;
            InsertSortButton.Click += InsertSortButton_Click;
            // 
            // sortName
            // 
            sortName.AutoSize = true;
            sortName.Font = new Font("Segoe UI", 14F);
            sortName.Location = new Point(314, 245);
            sortName.Name = "sortName";
            sortName.Size = new Size(67, 25);
            sortName.TabIndex = 9;
            sortName.Text = "Sorted";
            // 
            // BubbleSortButton
            // 
            BubbleSortButton.Font = new Font("Segoe UI", 13F);
            BubbleSortButton.Location = new Point(188, 350);
            BubbleSortButton.Name = "BubbleSortButton";
            BubbleSortButton.Size = new Size(79, 58);
            BubbleSortButton.TabIndex = 10;
            BubbleSortButton.Text = "Bubble Sort";
            BubbleSortButton.UseVisualStyleBackColor = true;
            BubbleSortButton.Click += BubbleSortButton_Click;
            // 
            // MergeSortButton
            // 
            MergeSortButton.Font = new Font("Segoe UI", 13F);
            MergeSortButton.Location = new Point(314, 350);
            MergeSortButton.Name = "MergeSortButton";
            MergeSortButton.Size = new Size(79, 58);
            MergeSortButton.TabIndex = 11;
            MergeSortButton.Text = "Merge Sort";
            MergeSortButton.UseVisualStyleBackColor = true;
            MergeSortButton.Click += MergeSortButton_Click;
            // 
            // QuickSortButton
            // 
            QuickSortButton.Font = new Font("Segoe UI", 13F);
            QuickSortButton.Location = new Point(438, 350);
            QuickSortButton.Name = "QuickSortButton";
            QuickSortButton.Size = new Size(71, 58);
            QuickSortButton.TabIndex = 12;
            QuickSortButton.Text = "Quick Sort";
            QuickSortButton.UseVisualStyleBackColor = true;
            QuickSortButton.Click += QuickSortButton_Click;
            // 
            // CountingSortButton
            // 
            CountingSortButton.Font = new Font("Segoe UI", 13F);
            CountingSortButton.Location = new Point(547, 350);
            CountingSortButton.Name = "CountingSortButton";
            CountingSortButton.Size = new Size(86, 58);
            CountingSortButton.TabIndex = 13;
            CountingSortButton.Text = "Couting Sort";
            CountingSortButton.UseVisualStyleBackColor = true;
            CountingSortButton.Click += CountingSortButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(737, 420);
            Controls.Add(CountingSortButton);
            Controls.Add(QuickSortButton);
            Controls.Add(MergeSortButton);
            Controls.Add(BubbleSortButton);
            Controls.Add(sortName);
            Controls.Add(InsertSortButton);
            Controls.Add(button2);
            Controls.Add(minusOne);
            Controls.Add(addOne);
            Controls.Add(splitter1);
            Controls.Add(arrayLength);
            Controls.Add(displayList);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox textBox1;
        private TextBox displayList;
        private TextBox arrayLength;
        private Splitter splitter1;
        private Button addOne;
        private Button minusOne;
        private Button button2;
        private Button InsertSortButton;
        private Label sortName;
        private Button BubbleSortButton;
        private Button MergeSortButton;
        private Button QuickSortButton;
        private Button CountingSortButton;
    }
}
