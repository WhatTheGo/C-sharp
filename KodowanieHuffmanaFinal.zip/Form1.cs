using System.Runtime.InteropServices;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<char, int> slownik = new Dictionary<char, int>();
        List<Node> tabelka = new List<Node>();
        List<Node> listaNodeGS;
        Dictionary<char, String> slownikKodowBinarnych = new Dictionary<char, String>();

        private void ZakodujButton_Click(object sender, EventArgs e)
        {
            Kodowanie();
        }

        public void Kodowanie()
        {
            StworzSlownik(); //slownik char, ilo�� wyst�powa�
            StworzTabelke(); //lista do drzewa 
            PosortujTabelke();
            listaNodeGS = new List<Node>(tabelka); //lista ze znakami
            StworzDrzewo();
            ZnajdzKodyBinarneListy();
            WyswietlKodBinarny();
        }

        public void WyswietlKodBinarny()
        {
            String str = "";
            String textNiezakodowany = textDoZakodowania.Text;
            foreach (char c in textNiezakodowany)
            {
                str += slownikKodowBinarnych[c];
            }
            MessageBox.Show(str);
        }
        public void ZnajdzKodyBinarneListy()
        {
            slownikKodowBinarnych.Clear();
            int i = listaNodeGS.Count;
            while (i > 0)
            {
                NodeGS node = (NodeGS)listaNodeGS[i-1];
                char c = node.symbol;
                slownikKodowBinarnych.Add(c, "");
                var rodzic = node.rodzic;

                if (rodzic.lewe == node)
                    slownikKodowBinarnych[c] += "0";
                else
                    slownikKodowBinarnych[c] += "1";

                while (rodzic.rodzic != null)
                {
                    if(rodzic.rodzic.lewe == rodzic)
                        slownikKodowBinarnych[c] += "0";
                    else
                        slownikKodowBinarnych[c] += "1";
                    rodzic = rodzic.rodzic;
                }
                slownikKodowBinarnych[c].Reverse();
                i--;
            }
        }
        public void StworzSlownik()
        {
            slownik.Clear();
            String str = textDoZakodowania.Text;
            foreach (char litera in str)
            {
                if (slownik.ContainsKey(litera))
                    slownik[litera]++;
                else
                    slownik.Add(litera, 1);
            }
        }

        public void StworzTabelke()
        {
            tabelka.Clear();
            foreach (var c in slownik.Keys)
            {
                tabelka.Add(new NodeGS(c, slownik[c]));
            }
        }

        public void PosortujTabelke()
        {
            tabelka = tabelka.OrderBy(n => n.data).ThenBy(n => n.GetType() == typeof(NodeGS) ? 0 : 1).ToList();
        }

        public void StworzDrzewo()
        {
            if (tabelka.Count == 1)
            {
                Node newNode = new Node(tabelka.ElementAt(0).data);
                newNode.lewe = tabelka.ElementAt(0);
                tabelka.ElementAt(0).rodzic = newNode;
                tabelka.RemoveAt(0);
                tabelka.Add(newNode);
            }
            while (tabelka.Count > 1)
            {
                PosortujTabelke();
                Node newNode = new Node(tabelka.ElementAt(0).data + tabelka.ElementAt(1).data);
                newNode.lewe = tabelka.ElementAt(0);
                newNode.prawe = tabelka.ElementAt(1);
                tabelka.ElementAt(0).rodzic = newNode;
                tabelka.ElementAt(1).rodzic = newNode;
                tabelka.RemoveAt(0);
                tabelka.RemoveAt(0);
                tabelka.Add(newNode);
            }
        }
    }
}