namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<char, int> slownik = new Dictionary<char, int>();
        List<Node> tabelka = new List<Node>();
        private void ZakodujButton_Click(object sender, EventArgs e)
        {
            StworzSlownik();
            StworzTabelke();
            while (tabelka.Count > 0)
            {

            }
            
        }

        public void StworzSlownik()
        {
            slownik.Clear();
            String str = textDoZakodowania.Text;
            foreach (char litera in str)
            {
                if (slownik.ContainsKey(litera))
                    slownik[litera]++;
                else
                    slownik.Add(litera, 1);
            }
        }

        public void StworzTabelke()
        {
            tabelka.Clear();
            foreach (var c in slownik.Keys)
            {
                tabelka.Add(new NodeGS(c, slownik[c]));
            }
        }

        public void PosortujTabelke()
        {
            tabelka.OrderBy(n => n.data).ThenBy(n => n.GetType() == typeof(NodeGS) ? 0 : 1);
        }
    }
}