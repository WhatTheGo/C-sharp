﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class NodeGS : Node
    {
        public char symbol;

        public NodeGS(char symbol, int data) : base(data)
        {
            this.symbol = symbol;
        }
    }
}
