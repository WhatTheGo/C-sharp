namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string text1, text2;
        int[,] tab;

        private void button1_Click(object sender, EventArgs e)
        {
            text1 = " " + textBox1.Text;
            text2 = " " + textBox2.Text;
            tab = new int[text1.Length + 1, text2.Length + 1];
            StworzTabelke();
            PrintTable();
        }

        private void StworzTabelke()
        {
            for (int i = 1; i < text1.Length; i++)
            {
                for (int j = 1; j < text2.Length; j++)
                {
                    if (text1[i] == text2[j])
                        tab[i, j] = tab[i - 1, j - 1] + 1;
                    else
                    {
                        if (tab[i - 1, j] > tab[i, j - 1])
                            tab[i, j] = tab[i - 1, j];
                        else
                            tab[i, j] = tab[i, j - 1];
                    }
                }
            }
        }

        private void PrintTable()
        {
            string s = "";
            for (int i = 0; i < text1.Length; i++)
            {
                for (int j = 0; j < text2.Length; j++)
                {
                    s += tab[i, j].ToString() + " ";
                }
                s += "\n";
            }
            label1.Text = s;
        }

        private void ZnajdzPodciag()
        {
            int i = tab.GetLength(0);
            int j = tab.GetLength(1);
            int n = tab[i, j];
            while (j>=0 && i>=0)
            {
                if (tab[i-1, j] == n)
                {
                    i--;
                }
                else if (tab[i, j-1] == n)
                {
                    j--;
                }
                else
                {

                }
            }
        }
    }
}