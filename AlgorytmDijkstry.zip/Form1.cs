namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Graf g = new Graf();
        private void Form1_Load(object sender, EventArgs e)
        {
            NodeG n0 = new NodeG(0);
            NodeG n1 = new NodeG(1);
            NodeG n2 = new NodeG(2);
            NodeG n3 = new NodeG(3);
            NodeG n4 = new NodeG(4);
            NodeG n5 = new NodeG(5);
            g.Add(new Edge(n0, n1, 3));
            g.Add(new Edge(n0, n4, 3));
            g.Add(new Edge(n1, n2, 1));
            g.Add(new Edge(n2, n3, 3));
            g.Add(new Edge(n3, n1, 3));
            g.Add(new Edge(n4, n5, 2));
            g.Add(new Edge(n5, n3, 1));
            g.Add(new Edge(n2, n5, 1));
            g.Add(new Edge(n5, n0, 6));

            List<Element> tabelka = g.$safeprojectname$(n0);
            string s = "";
            foreach(Element element in tabelka)
            {
                s += "n" + element.wezel.data + " d = " +
                    element.dystans + " p = " +
                    element.poprzednik.data + "\n";    
            }
            label1.Text = s;
        }
    }
}
