﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class BST
    {
        NodeT Root;

        public void Add(int liczba)
        {
            NodeT newNode = new NodeT(liczba);
            if (Root == null)
            { Root = newNode; }

            else
            {
                NodeT tmp = Root;
                bool exit = false;
                while (exit == false)
                {
                    if (liczba <= tmp.Data)
                    {
                        if(tmp.Lewa == null) 
                        { 
                            tmp.Lewa = newNode;
                            tmp.Lewa.Rodzic = tmp;
                            exit = true;

                        }
                        else { tmp = tmp.Lewa; }
                    }

                    else
                    {
                        if (tmp.Prawa == null)
                        {
                            tmp.Prawa = newNode;
                            tmp.Prawa.Rodzic = tmp;
                            exit = true;

                        }
                        else { tmp = tmp.Prawa; }
                    }

                }
                
            }
        }
    }
}
