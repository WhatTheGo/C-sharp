﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class BST
    {
        public NodeT Root;

        public void Remove(NodeT node)
        {
            if(node == null) { return; }
            else if (node.Lewa == null && node.Prawa == null)
            {
                Remove_Leaf(node);
            }
            else if (node.Lewa != null && node.Prawa != null)
            {
                Remove_Two(node);
            }
            else
            {
                Remove_One_Child(node);
            }
        }
        public NodeT Look_For_Min(NodeT node)
        {
            node = node.Prawa;
            while (node.Lewa != null)
            {
                node = node.Lewa;
            }
            return node;
        }
        public void Remove_Two(NodeT node)
        {
            NodeT newNode = Look_For_Min(node);

            if (node == Root && node.Prawa != newNode)
            {
                newNode.Rodzic.Lewa = null;
                newNode.Rodzic = null;
                node.Prawa.Rodzic = newNode;
                node.Lewa.Rodzic = newNode;
                newNode.Prawa = node.Prawa;
                node.Prawa = null;
                newNode.Lewa = node.Lewa;
                node.Lewa = null;
                Root = newNode;
            }
            else if(node == Root)
            {
                node.Prawa = null;
                newNode.Rodzic = null;
                node.Lewa.Rodzic = newNode;
                newNode.Lewa = node.Lewa;
                node.Lewa = null;
                Root = newNode;
            }
            else if (node.Prawa != newNode)
            {
                newNode.Rodzic.Lewa = null;
                newNode.Rodzic = null;
                node.Prawa.Rodzic = newNode;
                node.Lewa.Rodzic = newNode;
                newNode.Prawa = node.Prawa;
                node.Prawa = null;
                newNode.Lewa = node.Lewa;
                node.Lewa = null;
                newNode.Rodzic = node.Rodzic;
                newNode.Rodzic.Lewa = newNode;
            }
            else
            {
                node.Prawa = null;
                newNode.Rodzic = null;
                node.Lewa.Rodzic = newNode;
                newNode.Lewa = node.Lewa;
                node.Lewa = null;
                newNode.Rodzic = node.Rodzic;
                newNode.Rodzic.Lewa = newNode;
            }
        }

        public void Remove_Leaf(NodeT node)
        {
            if (node == Root) 
            { 
                Root = null;
                return;
            }
            else if (node.Rodzic.Lewa == node) { node.Rodzic.Lewa = null; }
            else { node.Rodzic.Prawa = null; }
            node.Rodzic = null;
        }

        public void Remove_One_Child(NodeT node)
        {
            if(node == Root)
            {
                if(node.Prawa != null)
                {
                    node.Prawa.Rodzic = null;
                    Root = node.Prawa;
                    node.Prawa = null;
                }
                else 
                {
                    node.Lewa.Rodzic = null;
                    Root = node.Lewa;
                    node.Lewa = null;
                }
            }
            else if (node.Rodzic.Lewa == node)
            {
                if (node.Lewa != null)
                {
                    node = node.Lewa;
                    node.Rodzic.Lewa = null;
                    node.Rodzic = node.Rodzic.Rodzic;
                    node.Rodzic.Lewa.Rodzic = null;
                    node.Rodzic.Lewa = node;
                }
                else
                {
                    node = node.Prawa;
                    node.Rodzic.Prawa = null;
                    node.Rodzic = node.Rodzic.Rodzic;
                    node.Rodzic.Lewa.Rodzic = null;
                    node.Rodzic.Lewa = node;
                }
            }
            else
            {
                if(node.Lewa != null)
                {
                    node = node.Lewa;
                    node.Rodzic.Lewa = null;
                    node.Rodzic = node.Rodzic.Rodzic;
                    node.Rodzic.Prawa.Rodzic = null;
                    node.Rodzic.Prawa = node;
                }
                else
                {
                    node = node.Prawa;
                    node.Rodzic.Prawa = null;
                    node.Rodzic = node.Rodzic.Rodzic;
                    node.Rodzic.Prawa.Rodzic = null;
                    node.Rodzic.Prawa = node;
                }
            }
        }

        public void Add(int liczba)
        {
            NodeT newNode = new NodeT(liczba);
            if (Root == null)
            { Root = newNode; }

            else
            {
                NodeT tmp = Root;
                bool exit = false;
                while (exit == false)
                {
                    if (liczba < tmp.Data)
                    {
                        if(tmp.Lewa == null) 
                        { 
                            tmp.Lewa = newNode;
                            newNode.Rodzic = tmp;
                            exit = true;

                        }
                        else { tmp = tmp.Lewa; }
                    }

                    else
                    {
                        if (tmp.Prawa == null)
                        {
                            tmp.Prawa = newNode;
                            newNode.Rodzic = tmp;
                            exit = true;

                        }
                        else { tmp = tmp.Prawa; }
                    }

                }
                
            }
        }
    }
}
