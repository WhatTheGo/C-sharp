﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class NodeT
    {
        public NodeT Rodzic;
        public NodeT Lewa;
        public NodeT Prawa;
        public int Data;

        public NodeT(int liczba)
        {
            this.Data = liczba;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
