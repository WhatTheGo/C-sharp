﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Add = new Button();
            AddInput = new TextBox();
            LabelTree = new Label();
            treeView = new TreeView();
            Remove = new Button();
            SuspendLayout();
            // 
            // Add
            // 
            Add.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            Add.Location = new Point(112, 37);
            Add.Name = "Add";
            Add.Size = new Size(56, 52);
            Add.TabIndex = 1;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // AddInput
            // 
            AddInput.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            AddInput.Location = new Point(46, 37);
            AddInput.Name = "AddInput";
            AddInput.Size = new Size(60, 52);
            AddInput.TabIndex = 2;
            // 
            // LabelTree
            // 
            LabelTree.AutoSize = true;
            LabelTree.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            LabelTree.Location = new Point(253, 37);
            LabelTree.Name = "LabelTree";
            LabelTree.Size = new Size(0, 37);
            LabelTree.TabIndex = 3;
            // 
            // treeView
            // 
            treeView.Location = new Point(46, 120);
            treeView.Name = "treeView";
            treeView.Size = new Size(334, 276);
            treeView.TabIndex = 4;
            // 
            // Remove
            // 
            Remove.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            Remove.Location = new Point(410, 120);
            Remove.Name = "Remove";
            Remove.Size = new Size(84, 52);
            Remove.TabIndex = 5;
            Remove.Text = "Remove";
            Remove.UseVisualStyleBackColor = true;
            Remove.Click += Remove_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Remove);
            Controls.Add(treeView);
            Controls.Add(LabelTree);
            Controls.Add(AddInput);
            Controls.Add(Add);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Add;
        private TextBox AddInput;
        private Label LabelTree;
        private TreeView treeView;
        private Button Remove;
    }
}
