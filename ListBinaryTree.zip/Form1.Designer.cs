﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TreeNode treeNode1 = new TreeNode("Root");
            treeView1 = new TreeView();
            Add = new Button();
            AddInput = new TextBox();
            SuspendLayout();
            // 
            // treeView1
            // 
            treeView1.Location = new Point(259, 58);
            treeView1.Name = "treeView1";
            treeNode1.Name = "Root";
            treeNode1.Text = "Root";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode1 });
            treeView1.Size = new Size(305, 304);
            treeView1.TabIndex = 0;
            // 
            // Add
            // 
            Add.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            Add.Location = new Point(112, 37);
            Add.Name = "Add";
            Add.Size = new Size(56, 52);
            Add.TabIndex = 1;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // AddInput
            // 
            AddInput.Font = new Font("Segoe UI", 25F, FontStyle.Regular, GraphicsUnit.Point);
            AddInput.Location = new Point(46, 37);
            AddInput.Name = "AddInput";
            AddInput.Size = new Size(60, 52);
            AddInput.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(AddInput);
            Controls.Add(Add);
            Controls.Add(treeView1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TreeView treeView1;
        private Button Add;
        private TextBox AddInput;
    }
}
