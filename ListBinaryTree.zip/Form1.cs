namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        BST tree = new BST();
        public Form1()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            Int32.TryParse(AddInput.Text, out int x);
            tree.Add(x);
        }
    }
}
