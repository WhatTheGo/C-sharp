namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        BST tree = new BST();
        public Form1()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            Int32.TryParse(AddInput.Text, out int x);
            tree.Add(x);
            LabelTree.Text = "";
            Print_Tree(tree.Root);
        }

        public void Print_Tree(NodeT tmp)
        {
            if (tmp == null) { return; }

            LabelTree.Text += tmp.Data.ToString() + " ";
            Print_Tree(tmp.Lewa);
            //LabelTree.Text += tmp.Data.ToString() + " ";
            Print_Tree(tmp.Prawa);
            // LabelTree.Text += tmp.Data.ToString() + " ";
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            tree.Remove(tree.Root.Lewa);
            LabelTree.Text = "";
            Print_Tree(tree.Root);
        }

        //public void Show_Tree(NodeT tmp)
        //{
        //    if (tmp == null) { return; }
        //    if (tmp == tree.Root)
        //    {
        //        treeView.Nodes.Clear();
        //        treeView.Nodes.Add(tmp.Data.ToString());
        //    }
        //    else
        //    {
        //        treeView.Nodes.Add(tmp.
        //    }
        //    Show_Tree(tmp.Lewa);
        //    Show_Tree(tmp.Prawa);
        //}
    }
}
