﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Graf
    {
        public List<NodeG> nodes = new List<NodeG>();
        public List<Edge> edges = new List<Edge>();

        public Graf(Edge k)
        {
            edges.Add(k);
            nodes.Add(edges[0].start);
            nodes.Add(edges[0].end);
        }

        public Graf() 
        {
            nodes.Clear();
            edges.Clear();
        }

        public int IleNowychWezlow(Edge k)
        {
            int ile = 0;

            if (!nodes.Contains(k.start))
            {
                ile++;
            }
            if (!nodes.Contains(k.end))
            {
                ile++;
            }

            return ile;
        }

        public void Add(Edge k)
        {
            if (!edges.Contains(k))
            {
                edges.Add(k);
                if (!nodes.Contains(k.start))
                {
                    nodes.Add(k.start);
                }
                if (!nodes.Contains(k.end))
                {
                    nodes.Add(k.end);
                }
            }
        }

        public void join(Graf g)
        {
            foreach (Edge k in g.edges)
            {
                if (!edges.Contains(k))
                {
                    this.Add(k);
                }
            }
        }

        public Boolean Czy0Nowych(List<Graf> grafs, Edge k)
        {
            foreach (Graf graf in grafs)
            {
                if(graf.IleNowychWezlow(k) == 0)
                {
                    return true;
                }
            }
            return false;
        }
        public Boolean Czy1Nowych(List<Graf> grafs, Edge k)
        {
            Boolean czyTrue = false;
            List<Graf> grafsWithAddedEges = new List<Graf>();
            int i = 0;
            int j = 0;
            int[] tab = new int[4];
            foreach (Graf graf in grafs)
            {
                if (graf.IleNowychWezlow(k) == 1)
                {
                    graf.Add(k);
                    czyTrue = true;
                    grafsWithAddedEges.Add(graf);
                    tab[j++] = i;
                }
                i++;
            }

            if (grafsWithAddedEges.Count == 2)
            {
                grafs[tab[0]].join(grafsWithAddedEges[1]);
                grafs.RemoveAt(tab[1]);
            }
            
            return czyTrue;
        }

        public Graf $safeprojectname$()
        {
            List<Edge> sortedEdges = edges.OrderBy(e => e.weight).ToList();
            List<Graf> grafs = new List<Graf>();
            Graf g = new Graf(sortedEdges[0]);
            grafs.Add(g);
            int j = 0;
            for (int i = 1; i < sortedEdges.Count; i++)
            {
                Edge k = sortedEdges[i];
                if (Czy0Nowych(grafs, k)) 
                {
                    continue; 
                }
                else if (Czy1Nowych(grafs, k)) 
                { 
                    continue;
                }
                else 
                { 
                    g = new Graf(k);
                    grafs.Add(g);
                }
            }

            return grafs[0];
        }
    }
}
