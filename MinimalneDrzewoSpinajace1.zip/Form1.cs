namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Graf g1 = new Graf();
        private void button1_Click(object sender, EventArgs e)
        {
            NodeG n0 = new NodeG(0);
            NodeG n1 = new NodeG(1);
            NodeG n2 = new NodeG(2);
            NodeG n3 = new NodeG(3);
            NodeG n4 = new NodeG(4);
            NodeG n5 = new NodeG(5);
            NodeG n6 = new NodeG(6);
            NodeG n7 = new NodeG(7);
            g1.Add(new Edge(n0, n1, 5));
            g1.Add(new Edge(n1, n2, 9));
            g1.Add(new Edge(n0, n3, 9));
            g1.Add(new Edge(n1, n4, 8));
            g1.Add(new Edge(n1, n5, 6));
            g1.Add(new Edge(n0, n6, 3));
            g1.Add(new Edge(n2, n3, 9));
            g1.Add(new Edge(n3, n6, 8));
            g1.Add(new Edge(n2, n4, 4));
            g1.Add(new Edge(n4, n5, 2));
            g1.Add(new Edge(n4, n6, 1));
            g1.Add(new Edge(n5, n6, 6));
            g1.Add(new Edge(n2, n6, 5));
            g1.Add(new Edge(n1, n7, 7));
            g1.Add(new Edge(n2, n7, 3));
            g1.Add(new Edge(n6, n7, 9));

            Graf drzewo = g1.$safeprojectname$();
            string a = "";
            for (int i = 0; i < drzewo.edges.Count; i++)
            {
                a += drzewo.edges[i].start.data + "-" + drzewo.edges[i].end.data + "  " + drzewo.edges[i].weight + "\n";
            }
            label1.Text = a;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
